-- ============================================================================
-- Casus — permanent sign-up fix.
-- Approves everyone waiting, and auto-approves every future sign-up at the
-- database level, so Supabase's free email limit can never block anyone again.
-- Run once: Supabase -> SQL Editor -> paste -> Run.
-- ============================================================================

-- 1) Approve everyone who is currently stuck
update auth.users set email_confirmed_at = now() where email_confirmed_at is null;

-- 2) Auto-approve every new sign-up the instant the account is created
create or replace function public.auto_confirm_user()
returns trigger language plpgsql security definer as $$
begin
  if new.email_confirmed_at is null then
    new.email_confirmed_at := now();
  end if;
  return new;
end; $$;

drop trigger if exists auto_confirm_on_signup on auth.users;
create trigger auto_confirm_on_signup
  before insert on auth.users
  for each row execute function public.auto_confirm_user();
